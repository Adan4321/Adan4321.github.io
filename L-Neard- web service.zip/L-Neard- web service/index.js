const express = require('express');
const fs = require('fs');
const cors = require('cors');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


app.use(express.static('./static'));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'static', 'html', 'index.html'));
});



app.post('/guardar', (req, res) => {
  console.log(req.body);
  const data = req.body; 
  const fecha = data.date; 
  const contenido = `${fecha},${data.km},${data.details} \n`;
  console.log(contenido);
  fs.access('./static/datos/registro.csv', fs.constants.F_OK, (err) => {
    console.log('acediendo al archivo')
    if (err) {
      // El archivo no existe, agregamos los encabezados
      console.log('archivo no encontrado, creando encabezados')
      const encabezados = "Fecha,Kilometros,Detalles\n";
      fs.writeFile('./static/datos/registro.csv', encabezados + contenido, err => {
        console.log('escribiendo datos en el archivo')
        if (err) { handleError(err, res); } 
        else { res.send('Datos guardados correctamente'); }
      });
    } else {
      const encabezados = "Fecha,Kilometros,Detalles\n";
      console.log('archivo existente, cargando datos')
      // El archivo existe, solo agregamos los datos
      try {
        fs.appendFile('./static/datos/registro.csv', contenido, err => {
            if (err) { handleError(err, res); }
            else { res.send('Datos añadidos correctamente'); }
        });
    } catch (error) {
        handleError(error, res);
    }
    
 
    }
  });
});

const handleError = (err, res) => {
  console.log(err);
  res.status(500).send('Error al guardar el archivo: ' + err);
  console.error(err);
}
app.get('/verDatos', (req, res) => {
  fs.readFile('./static/datos/registro.csv', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error al leer el archivo');
    } else {
      const filas = data.trim().split(' ').filter(fila => fila.trim() !== ''); // Filtrar líneas vacías
      const contenidoFiltrado = filas.join(' '); // Volver a unir las filas
      res.send(contenidoFiltrado); // Envía el contenido filtrado del archivo CSV al cliente
    }
  });
});

app.delete('/borrar/:km', (req, res) => {
  const kmABorrar = req.params.km;
  fs.readFile('./static/datos/registro.csv', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error al leer el archivo');
    } else {
      const filas = data.trim().split('\n').filter(fila => {
        const campos = fila.split(',');
        return campos[1] !== kmABorrar; // Filtramos por kilometraje
      });
      const contenidoFiltrado = filas.join('\n') + '\n';
      fs.writeFile('./static/datos/registro.csv', contenidoFiltrado, err => {
        if (err) { handleError(err, res); }
        else { res.send('Dato borrado correctamente'); }
      });
    }
  });
});




const PORT = 80;  
app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});
