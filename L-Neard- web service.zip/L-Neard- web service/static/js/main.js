document.getElementById('serviceForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const date = document.getElementById('date').value;
    const km = document.getElementById('km').value;
    const details = document.getElementById('details').value;

    fetch('/guardar', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ date, km, details })
        
    })
        .then(response => response.text())
        .then(data => {
            console.log(data); // Mostrar mensaje de confirmación
            // Puedes agregar aquí la lógica para mostrar un mensaje al usuario
        })
        .catch(error => {
            console.error('Error:', error);
            // Manejar el error, por ejemplo, mostrar un mensaje de error al usuario
        });
        mostrarTabla();
        document.getElementById('date').value="";
        document.getElementById('km').value="";
        document.getElementById('details').value="";
        
      
});
function mostrarTabla() {
    fetch('/verDatos')
        .then(response => response.text())
        .then(data => {
            const filas = data.split('\n').map(fila => fila.split(','));
            // Eliminar la primera fila si es el encabezado
            const encabezados = filas[0];
            const datos = filas.slice(1);
            if (datos.length > 1) { }
            let tablaHTML = `<table><thead><tr>`;
            encabezados.forEach(encabezado => tablaHTML += `<th>${encabezado}</th>`);
            tablaHTML += `</tr></thead><tbody>`;

            datos.forEach(fila => {
                tablaHTML += `<tr>`;
                fila.forEach(dato => tablaHTML += `<td>${dato}</td>`);
                tablaHTML += `</tr>`;
            });

            tablaHTML += `</tbody></table>`;
            document.getElementById('tablaServicios').innerHTML = tablaHTML; // Asegúrate de tener un elemento con id='tablaServicios'

        })
        .catch(error => console.error('Error:', error));

}
mostrarTabla()
function borrar() {
    let kilometrajeABorrar =document.getElementById('kilometraje').value;
    fetch('/borrar/' + kilometrajeABorrar, {
        method: 'DELETE'
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al borrar el dato');
            }
            return response.text();
        })
        .then(data => {
            console.log(data); // Mensaje de confirmación
            // Aquí puedes actualizar tu tabla para reflejar el cambio
        })
        .catch(error => {
            console.error('Error:', error);
        });

        document.getElementById('kilometraje').value='';
mostrarTabla()




}